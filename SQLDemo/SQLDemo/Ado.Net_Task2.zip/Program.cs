﻿using System;

namespace SQLDemo
{
    public class Program
    {
        static void Main(string[] args)
        {
            // Creating an instance of MenuOptions to access user menu
            MenuOptions menuOptions = new MenuOptions();
            // Calling UserOptions method to display menu and handle user input
            menuOptions.UserOptions();
        }
    }
}
