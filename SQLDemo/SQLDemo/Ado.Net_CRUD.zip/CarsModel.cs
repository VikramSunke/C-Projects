﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLDemo
{
    public class CarsModel
    {
        public int id { get; set; }
        public string carName { get; set; }
  
        public int carPrice { get; set; }
        public string carColor { get; set; }

    }
}



