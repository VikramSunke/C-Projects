﻿using System;

namespace SQLDemo
{
    public class Program
    {
        static void Main(string[] args)
        {
            MenuOptions menuOptions = new MenuOptions();
            menuOptions.UserOptions();
        }
    }
}
